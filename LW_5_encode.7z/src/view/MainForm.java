package view;

import domain.data.Txt;
import domain.entities.*;
import model.MyTableModel;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;

public class MainForm extends JFrame {
    private File path = new File("C:\\Users\\Алемор\\Desktop\\Саша\\Обучение\\ООП\\LW_5\\OOP_LW_5");
    // C:\Users\stud\Desktop\Alemor\LW_5_encode
    // C:\Users\Алемор\Desktop\Саша\Обучение\ООП\LW_5\OOP_LW_5
    private JFrame frame;
    private JButton btnAddRow;
    private JButton btnDeleteRow;
    private JMenuBar menuBar;
    private JMenu helpMenu;
    private JMenuItem helpItem;
    private JMenu aboutMenu;
    private JMenuItem aboutProgramItem;
    private JMenu fileMenu;
    private JMenuItem openItem;
    private JMenuItem saveItem;
    private JTable table;
    private MyTableModel tableModel;
    private JPanel mainPanel;
    private JPanel eastPanel;
    private JFileChooser fileChooser;
    ArrayList<Product> products = new ArrayList<>();
    public class saveFile implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            fileChooser.setDialogTitle("Сохранение файла");
            // Определение режима - только файл
            fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
            int result = fileChooser.showSaveDialog(MainForm.this);
            // Если файл выбран, то представим его в сообщении
            if (result == JFileChooser.APPROVE_OPTION ) {
                JOptionPane.showMessageDialog(MainForm.this,
                        "Файл '" + fileChooser.getSelectedFile() +
                                " ) сохранен");
                Txt.setFilename(fileChooser.getSelectedFile(), fileChooser.getCurrentDirectory().toString());
                Txt.writeArrayToFile(tableModel.getData());
            }
        }
    }
    public void loadTable(){
        tableModel.changeData(products);
    }
    public class openFile implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            fileChooser.setDialogTitle("Открыть файл");
            // Определение режима - только файл
            fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
            int result = fileChooser.showOpenDialog(MainForm.this);
            // Если файл выбран, то представим его в сообщении
            if (result == JFileChooser.APPROVE_OPTION ) {
                JOptionPane.showMessageDialog(MainForm.this,
                        "Файл '" + fileChooser.getSelectedFile() +
                                " ) загружен");
                Txt.setFilename(fileChooser.getSelectedFile(), fileChooser.getCurrentDirectory().toString());
                if (Txt.nullFileOrNotNull()){
                    products = Txt.readProductsFromFile();
                    loadTable();
                }
            }
        }
    }
    public MainForm(){
        super();
        initialization();
        start();
    }
    public void initialization(){
        frame = new JFrame("App for Buy");
        frame.setSize(1200, 800);
        frame.setLocationByPlatform(true);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        //frame.setIconImage();

        mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());

        eastPanel = new JPanel();
        eastPanel.setLayout(new BoxLayout(eastPanel, BoxLayout.Y_AXIS));

        menuBar = new JMenuBar();

        aboutMenu = new JMenu("About");
        aboutProgramItem = new JMenuItem("About program");
        aboutProgramItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(MainForm.this, "This program was created by 2nd year student " +
                        "Alexander Morgunov in the direction of ISTB-22-1.\n The program is designed to view, add, delete purchases in table form" +
                        "\n version 0.1");
            }
        });

        helpMenu = new JMenu("Help");
        helpItem = new JMenuItem("Help notes");
        helpItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(MainForm.this, "\"File\" => \"Save File\": Saves data to the selected file\n" +
                        "\"File\" => \"Open File\": Loads data from a file\n" +
                        "\"About Program\": Tells about the program\n" +
                        "\"Add Row\": Adds a new row to the table\n" +
                        "\"Delete Row\": Deletes the selected row in the table");
            }
        });

        fileMenu = new JMenu("File");

        saveItem = new JMenuItem("Save");
        saveItem.addActionListener(new saveFile());

        openItem = new JMenuItem("Open");
        openItem.addActionListener(new openFile());

        tableModel = new MyTableModel(products);

        table = new JTable(tableModel);

        btnAddRow = new JButton("Add new product");
        btnAddRow.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // JOptionPane input поле для ввода нового продукта
                tableModel.addRow();
            }
        });

        btnDeleteRow = new JButton("Delete selected product");
        btnDeleteRow.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    tableModel.deleteRow(table.getSelectedRow());
                }catch (IndexOutOfBoundsException ex){
                    JOptionPane.showMessageDialog(MainForm.this, "Unselected line");
                }catch (IllegalArgumentException ex){
                    JOptionPane.showMessageDialog(MainForm.this, "Too many rows selected");
                }
            }
        });

        fileChooser = new JFileChooser(path);
    }

    public void showErrorWrongFormat(){
        JOptionPane.showMessageDialog(MainForm.this,"Wrong format");;
    }
    public void start(){
        aboutMenu.add(aboutProgramItem);
        helpMenu.add(helpItem);
        fileMenu.add(saveItem);
        fileMenu.add(openItem);

        menuBar.add(fileMenu);
        menuBar.add(helpMenu);
        menuBar.add(aboutMenu);

        eastPanel.add(btnAddRow);
        eastPanel.add(btnDeleteRow);

        mainPanel.add(eastPanel, BorderLayout.WEST);
        mainPanel.add(menuBar, BorderLayout.NORTH);
        mainPanel.add(new JScrollPane(table));

        frame.add(mainPanel);
        frame.setVisible(true);
    }
}
